package com.springboot.core.spring_boot_loose_coupling;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootLooseCouplingApplicationTests {

	@Test
	void contextLoads() {
	}

}
